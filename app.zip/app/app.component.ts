 import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { ProductService } from './product.service';
 
// import { Product } from '../models/product';
// Define the Product interface within the component file
interface Product {
  id?: number;
  name: string;
  description: string;
  price: number;
  category: string;
  stock: number;
}

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})
// export class AppComponent implements OnInit {
// closeAddProduct() {
// throw new Error('Method not implemented.');
// }
// openAddProduct() {
// throw new Error('Method not implemented.');
// }
//   products: Product[] = [];
//   productForm: FormGroup;
//   editForm: FormGroup;
//   selectedProduct: Product | null = null;
// showAddModal: any;

//   constructor(
//     private productService: ProductService,
//     private fb: FormBuilder
//   ) {
//     this.productForm = this.fb.group({
//       name: ['', Validators.required],
//       description: ['', Validators.required],
//       price: [0, Validators.required],
//       category: ['', Validators.required],
//       stock: [0, Validators.required]
//     });

//     this.editForm = this.fb.group({
//       id: [''],
//       name: ['', Validators.required],
//       description: ['', Validators.required],
//       price: [0, Validators.required],
//       category: ['', Validators.required],
//       stock: [0, Validators.required]
//     });
//   }

//   ngOnInit(): void {
//     this.loadProducts();
//   }

//   loadProducts(): void {
//     this.productService.getProducts().subscribe((data: Product[]) => {
//       this.products = data;
//     });
//   }

//   addProduct(): void {
//     if (this.productForm.valid) {
//       this.productService.addProduct(this.productForm.value).subscribe(() => {
//         this.loadProducts();
//         this.productForm.reset();
//       });
//     }
//   }

//   editProduct(product: Product): void {
//     this.selectedProduct = product;
//     this.editForm.setValue(product);
//   }

//   updateProduct(): void {
//     if (this.editForm.valid) {
//       this.productService.updateProduct(this.editForm.value.id, this.editForm.value).subscribe(() => {
//         this.loadProducts();
//         this.selectedProduct = null;
//       });
//     }
//   }

//   deleteProduct(id: number): void {
//     this.productService.deleteProduct(id).subscribe(() => {
//       this.loadProducts();
//     });
//   }

//   cancelEdit(): void {
//     this.selectedProduct = null;
//   }
// }

// import { Component, OnInit } from '@angular/core';
// import { FormBuilder, FormGroup, Validators } from '@angular/forms';
// import { ProductService } from '../services/product.service';

// Define the Product interface within the component file
 
 export class AppComponent implements OnInit {
  products: Product[] = [];
  productForm: FormGroup;
  editForm: FormGroup;
  selectedProduct: Product | null = null;
  showAddModal = false;

  constructor(
    private productService: ProductService,
    private fb: FormBuilder
  ) {
    this.productForm = this.fb.group({
      name: ['', Validators.required],
      description: ['', Validators.required],
      price: [0, Validators.required],
      category: ['', Validators.required],
      stock: [0, Validators.required]
    });

    this.editForm = this.fb.group({
      id: [''],
      name: ['', Validators.required],
      description: ['', Validators.required],
      price: [0, Validators.required],
      category: ['', Validators.required],
      stock: [0, Validators.required]
    });
  }

  ngOnInit(): void {
    this.loadProducts();
  }

  loadProducts(): void {
    this.productService.getProducts().subscribe((data: Product[]) => {
      this.products = data;
    });
  }

  addProduct(): void {
    if (this.productForm.valid) {
      this.productService.addProduct(this.productForm.value).subscribe(() => {
        this.loadProducts();
        this.closeAddProduct();
      });
    }
  }

  editProduct(product: Product): void {
    this.selectedProduct = product;
    this.editForm.setValue(product);
  }

  updateProduct(): void {
    if (this.editForm.valid) {
      this.productService.updateProduct(this.editForm.value.id, this.editForm.value).subscribe(() => {
        this.loadProducts();
        this.selectedProduct = null;
      });
    }
  }

  deleteProduct(id: number): void {
    this.productService.deleteProduct(id).subscribe(() => {
      this.loadProducts();
    });
  }

  cancelEdit(): void {
    this.selectedProduct = null;
  }

  openAddProduct(): void {
    this.showAddModal = true;
  }

  closeAddProduct(): void {
    this.showAddModal = false;
    this.productForm.reset();
  }
}
